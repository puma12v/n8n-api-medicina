# n8n-api-medicina
Instância do n8n para servir como API de perguntas médicas via Webhook